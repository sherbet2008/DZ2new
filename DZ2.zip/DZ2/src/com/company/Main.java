package com.company;
import java.util.Random;
public class Main {

    private static int bound;

    public static int generateRandomAge() {
        Random random = new Random();
        return random.nextInt( bound; 60);

    }
    public static int generateRandomTemp() {
        Random random = new Random();
        return random.nextInt(bound:40 ) - 20 ;
    }
      public static String func (int age, int temp){
        if(age<20 && age>45 && temp>-20 && temp<30) {
            return "можно идти гулять";
        }
        else if (age<20 && temp>0 && temp <28) {
            return "можно идти гулять";
        }
        else if (age>45 && temp>-10 temp>25){
              return "можно идти гулять";
          }
        else if return "Остовайтесь дома";
        }
    }

